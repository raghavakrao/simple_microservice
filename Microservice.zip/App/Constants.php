<?php
namespace App;

/**
 * Constants
 *
 * Contains all constants related to Microservices
 *
 * @category   Constants
 * @package    Microservices
 * @author     
 * @copyright  
 * @version    Release: @1.0.0@
 * @since      Class available since Release 1.0.0
 */
class Constants
{

}