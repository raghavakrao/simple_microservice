<?php
return [
    'global' => [
        '{table:string}' => [
            '{id:int}'  => [
                '__file__' => __DOC_ROOT__ . '/Config/Queries/GlobalDB/PATCH/CRUD.php',
            ],
        ]
    ],
    'client' => [
        '{table:string}' => [
            '{id:int}'  => [
                '__file__' => __DOC_ROOT__ . '/Config/Queries/ClientDB/PATCH/CRUD.php',
            ],
        ]
    ]       
];
